<?php
        use Carbon\Carbon;
        $dates = Carbon::now();?>
@extends('layouts.app')

@section('content')
    <div class="container">

        <div class=" col-md-auto">
            <div class="panel panel-default">
                @if(Auth::check())
                   <div class="panel-heading">
                       <p id="txt" class="text text-sm-left"> </p>
                   </div>
                   <div class="panel-body">

                   <!-- Display Validation Error-->
                   @include('common.errors')

                   <!-- New Task Form -->
                   <form action="{{ url('task')}}" method="POST" class="form-horizontal">
                   {{ csrf_field() }}

                   <!-- Task Name -->
                       <div class="form-group">
                           <label for="task-name" class="col-md-auto control-label">Новая задача</label>
                           <div class="col-md-auto">
                               <input type="text" name="name" id="task-name" class="form-control" value="{{ old('task') }}">
                           </div>
                           <div class="col-sm-4">
                              <input type="datetime-local"  name="time" id="task_time" class="form-control" value="{{$dates->timezone('Europe/Moscow')->format('H:i:s d.m.Y')}}">
                           </div>
                       </div>

                       <!-- Add Task Button -->
                       <div class="form-group">
                           <div class="col-sm-offset-3 col-sm-6">
                               <button type="submit" class="btn btn-default">
                                  Добавить задачу
                               </button>
                           </div>
                       </div>
                   </form>
                </div>
                @endif
            </div>

            <!-- Current Tasks -->
            @if (count($tasks) > 0)
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Текущая задача
                    </div>
                    <div class="panel-body">
                        <table class="table table-success ">
                            <thead class="thead-dark">
                            <th>Task</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            </thead>
                            <tbody>
                            @foreach ($tasks as $task)
                                <?php
                                    $raznica_chas = Carbon::parse($task->leftdate)->format('H') - $dates->timezone('Europe/Moscow')->format('H');
                                    $neww=((Carbon::parse($task->leftdate))->format('d') - $dates->timezone('Europe/Moscow')->format('d'));
                                    $delta_hours = (Carbon::parse($task->leftdate)->format('H') - $dates->timezone('Europe/Moscow')->format('H'));
                                    $delta_min = (Carbon::parse($task->leftdate)->format('i') - $dates->timezone('Europe/Moscow')->format('i'));
                                ?>
                                <tr>
                                    @if($task->userid == Auth::id()|| Auth::id() == 1)
                                       @if(((($neww==0)) and $delta_hours >1)or (($neww>0)))
                                            <td class="table-text">
                                                <div>{{ $task->name }}</div>
                                            </td>
                                            <td>
                                                <div>Создана: {{$task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')}}</div>
                                            </td>
                                            <td>
                                                <div>Добавил: {{$task->Username}}</div>
                                                <div>Выполнить до: {{Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')}}</div>
                                            </td>
                                            <!-- Task Delete Button -->
                                            <td>
                                                <form action="{{ url('task/'.$task->id) }}" method="POST">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           @endif
                                           @if((($neww==0)and $delta_hours <=1) and ($delta_hours >=0) and ($delta_min > 0))
                                            <td class="table-text table-warning">
                                                <div>{{ $task->name }}</div>
                                            </td>
                                            <td class="table-text table-warning">
                                                <div>Создана: {{$task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')}}</div>
                                            </td>
                                            <td class="table-text table-warning">
                                                <div>Добавил: {{$task->Username}}</div>
                                                <div>Выполнить до: {{Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')}}</div>
                                                <div>Осталось менее часа</div>
                                            </td>
                                            <!-- Task Delete Button -->
                                            <td class="table-text table-warning">
                                                <form action="{{ url('task/'.$task->id) }}" method="POST">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           @endif
                                           @if(($neww<0) or (($neww==0)and (Carbon::parse($task->leftdate)->format('H:i:s d.m.Y'))<($dates->timezone('Europe/Moscow')->format('H:i:s d.m.Y'))))
                                            <td class="table-text table-danger">
                                                <div>{{ $task->name }}</div>
                                            </td>
                                            <td class="table-text table-danger">
                                                <div>Создана: {{$task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')}}</div>
                                            </td>
                                            <td class="table-text table-danger">
                                                <div>Добавил: {{$task->Username}}</div>
                                                <div>Выполнить до: {{Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')}}</div>
                                                 <div>Время истекло</div>

                                            </td>
                                            <!-- Task Delete Button -->
                                            <td class="table-text table-danger">
                                                <form action="{{ url('task/'.$task->id) }}" method="POST">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           @endif
                                    @endif
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif
        </div>
    </div>
@endsection
