<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('register')); ?>" method="POST" class="form-horizontal">
<?php echo e(csrf_field()); ?>


<!-- Task Name -->
    <div class="form-group">
        <label for="task-name" class="col-sm-3 control-label">New user register</label>

        <div class="col-sm-6">
            <input type="text" name="username" id="user-name" class="form-control" value="<?php echo e(old('user')); ?>">
        </div>
    </div>

    <!-- Add Task Button -->
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-6">
            <button type="submit" class="btn btn-default">
                <i class="fa fa-btn fa-plus"></i>Add user
            </button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>