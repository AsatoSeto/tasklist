<?php
        use Carbon\Carbon;
        $dates = Carbon::now();?>


<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class=" col-md-auto">
            <div class="panel panel-default">
                <?php if(Auth::check()): ?>
                   <div class="panel-heading">
                       <p id="txt" class="text text-sm-left"> </p>
                   </div>
                   <div class="panel-body">

                   <!-- Display Validation Error-->
                   <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                   <!-- New Task Form -->
                   <form action="<?php echo e(url('task')); ?>" method="POST" class="form-horizontal">
                   <?php echo e(csrf_field()); ?>


                   <!-- Task Name -->
                       <div class="form-group">
                           <label for="task-name" class="col-md-auto control-label">Новая задача</label>
                           <div class="col-md-auto">
                               <input type="text" name="name" id="task-name" class="form-control" value="<?php echo e(old('task')); ?>">
                           </div>
                           <div class="col-sm-4">
                              <input type="datetime-local"  name="time" id="task_time" class="form-control" value="<?php echo e($dates->timezone('Europe/Moscow')->format('H:i:s d.m.Y')); ?>">
                           </div>
                       </div>

                       <!-- Add Task Button -->
                       <div class="form-group">
                           <div class="col-sm-offset-3 col-sm-6">
                               <button type="submit" class="btn btn-default">
                                  Добавить задачу
                               </button>
                           </div>
                       </div>
                   </form>
                </div>
                <?php endif; ?>
            </div>

            <!-- Current Tasks -->
            <?php if(count($tasks) > 0): ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Текущая задача
                    </div>
                    <div class="panel-body">
                        <table class="table table-success ">
                            <thead class="thead-dark">
                            <th>Task</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $raznica_chas = Carbon::parse($task->leftdate)->format('H') - $dates->timezone('Europe/Moscow')->format('H');
                                    $neww=((Carbon::parse($task->leftdate))->format('d') - $dates->timezone('Europe/Moscow')->format('d'));
                                    $delta_hours = (Carbon::parse($task->leftdate)->format('H') - $dates->timezone('Europe/Moscow')->format('H'));
                                    $delta_min = (Carbon::parse($task->leftdate)->format('i') - $dates->timezone('Europe/Moscow')->format('i'));
                                ?>
                                <tr>
                                    <?php if($task->userid == Auth::id()|| Auth::id() == 1): ?>
                                       <?php if(((($neww==0)) and $delta_hours >1)or (($neww>0))): ?>
                                            <td class="table-text">
                                                <div><?php echo e($task->name); ?></div>
                                            </td>
                                            <td>
                                                <div>Создана: <?php echo e($task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')); ?></div>
                                            </td>
                                            <td>
                                                <div>Добавил: <?php echo e($task->Username); ?></div>
                                                <div>Выполнить до: <?php echo e(Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')); ?></div>
                                            </td>
                                            <!-- Task Delete Button -->
                                            <td>
                                                <form action="<?php echo e(url('task/'.$task->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>


                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           <?php endif; ?>
                                           <?php if((($neww==0)and $delta_hours <=1) and ($delta_hours >=0) and ($delta_min > 0)): ?>
                                            <td class="table-text table-warning">
                                                <div><?php echo e($task->name); ?></div>
                                            </td>
                                            <td class="table-text table-warning">
                                                <div>Создана: <?php echo e($task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')); ?></div>
                                            </td>
                                            <td class="table-text table-warning">
                                                <div>Добавил: <?php echo e($task->Username); ?></div>
                                                <div>Выполнить до: <?php echo e(Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')); ?></div>
                                                <div>Осталось менее часа</div>
                                            </td>
                                            <!-- Task Delete Button -->
                                            <td class="table-text table-warning">
                                                <form action="<?php echo e(url('task/'.$task->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>


                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           <?php endif; ?>
                                           <?php if(($neww<0) or (($neww==0)and (Carbon::parse($task->leftdate)->format('H:i:s d.m.Y'))<($dates->timezone('Europe/Moscow')->format('H:i:s d.m.Y')))): ?>
                                            <td class="table-text table-danger">
                                                <div><?php echo e($task->name); ?></div>
                                            </td>
                                            <td class="table-text table-danger">
                                                <div>Создана: <?php echo e($task->created_at->timezone('Europe/Moscow')->format('H:i:s d.m.Y')); ?></div>
                                            </td>
                                            <td class="table-text table-danger">
                                                <div>Добавил: <?php echo e($task->Username); ?></div>
                                                <div>Выполнить до: <?php echo e(Carbon::parse($task->leftdate)->format('H:i:s d.m.Y')); ?></div>
                                                 <div>Время истекло</div>

                                            </td>
                                            <!-- Task Delete Button -->
                                            <td class="table-text table-danger">
                                                <form action="<?php echo e(url('task/'.$task->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>


                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fa fa-btn fa-trash"></i>Delete
                                                    </button>
                                                </form>
                                            </td>
                                           <?php endif; ?>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>